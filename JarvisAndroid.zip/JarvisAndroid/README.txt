JARVIS ANDROID - build steps

1. Laptop par Android Studio install karo (developer.android.com/studio).
2. Is zip ko extract karo. Android Studio mein File > Open > JarvisAndroid folder chuno.
3. Pehli baar Gradle sync chalega aur SDK 35 download maangega - Accept/Install karo. (Thoda time lagta hai.)
4. Phone mein Settings > About phone > Software information > Build number 7 baar dabao (Developer mode).
5. Settings > Developer options > USB debugging ON karo. Phone ko USB se laptop se jodo, "Allow" karo.
6. Android Studio mein upar green Run (play) button dabao. App phone mein install ho jayegi.
   (APK chahiye to: Build > Build Bundle(s)/APK(s) > Build APK(s))
7. Phone mein Jarvis app kholo: Mic permission do, Accessibility ON karo, Gemini key save karo.
8. Agar Accessibility ka switch grey ho: Settings > Apps > Jarvis > 3 dots (upar right) > "Allow restricted settings", phir dobara try karo.

BINA ANDROID STUDIO (GitHub se APK banao):
1. github.com/new par naya repo banao (naam: jarvis-app).
2. Is folder ki SAARI files/folders (.github folder samet) repo ke "uploading an existing file" page par laptop se drag-drop karo, Commit karo.
3. Repo mein Actions tab kholo, "Build APK" run hone do (5-10 min).
4. Run khulne par neeche Artifacts mein "Jarvis-APK" download karo, zip kholo, app-debug.apk phone mein install karo.
